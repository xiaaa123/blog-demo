/**
 * Minified by jsDelivr using Terser v3.14.1.
 * Original file: /gh/mashirozx/sakura@3.3.1/cdn/js/lib.js
 *
 * Do NOT use SRI with dynamically generated files! More information: https://www.jsdelivr.com/using-sri-with-dynamic-files
 */